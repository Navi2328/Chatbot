const chatbox = document.getElementById('chatbox');
const userInput = document.getElementById('userInput');

function sendMessage() {
  const userMessage = userInput.value.trim();
  if (userMessage === '') return;

  // Display user's message
  displayMessage(userMessage, 'user');
  userInput.value = '';

  // Send user's message to the server
  fetch('http://127.0.0.1:5000/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: userMessage }),
  })
    .then(response => {
      if (!response.ok) throw new Error('Network response was not ok');
      return response.json();
    })
    .then(data => {
      // Display bot's response
      displayMessage(data.reply, 'bot');
    })
    .catch(err => {
      console.error('Error:', err);
      displayMessage('Something went wrong. Please try again.', 'bot');
    });
}

function displayMessage(message, sender) {
  const messageDiv = document.createElement('div');
  messageDiv.classList.add('message', sender);
  messageDiv.textContent = message;
  chatbox.appendChild(messageDiv);
  chatbox.scrollTop = chatbox.scrollHeight; // Scroll to the bottom
}
