from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable Cross-Origin Resource Sharing

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message', '').lower()

    # Basic chatbot logic
    if 'hello' in user_message:
        reply = "Hi there! How can I assist you?"
    elif 'how are you' in user_message:
        reply = "I'm just a bot, but I'm doing great! How about you?"
    elif 'bye' in user_message:
        reply = "Goodbye! Have a great day!"
    else:
        reply = "I'm sorry, I didn't understand that. Could you rephrase?"

    return jsonify({'reply': reply})

if __name__ == '__main__':
    app.run(debug=True)
